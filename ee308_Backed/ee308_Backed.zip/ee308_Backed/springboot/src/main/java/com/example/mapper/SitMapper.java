package com.example.mapper;


import com.example.entity.Sit;

import java.util.List;

//座位相关数据接口
public interface SitMapper {

    /**
     * 新增
     */
    int insert(Sit sit);

    /**
     * 删除
     */
    int deleteById(Integer id);

    /**
     * 修改
     */
    int updateById(Sit sit);

    /**
     * 根据ID查询
     */
    static Sit selectById(Integer id) {
        return null;
    }

    /**
     * 查询所有
     */
    List<Sit> selectAll(Sit sit);

}