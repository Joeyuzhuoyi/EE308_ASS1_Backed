package com.example.common.enums;

public enum RoleEnum {
    //图书馆管理员
    ADMIN,
    //自习室管理员
    LIBADMIN,
    //学生/自习者
    STUDENT
}
