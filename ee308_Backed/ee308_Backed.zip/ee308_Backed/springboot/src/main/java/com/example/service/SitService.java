package com.example.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.enums.ResultCodeEnum;
import com.example.common.enums.RoleEnum;
import com.example.common.enums.StatusEnum;
import com.example.entity.Account;
import com.example.entity.Room;
import com.example.entity.Sit;
import com.example.exception.CustomException;
import com.example.mapper.RoomMapper;
import com.example.mapper.SitMapper;
import com.example.utils.TokenUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 座位业务处理
 **/
@Service
public class SitService {

    @Resource
    private SitMapper sitMapper;
    @Resource
    private RoomMapper roomMapper;

    /**
     * 新增
     */
    public void add(Sit sit) {
        // 查询该座位所属自习室管理员信息
        Room room = roomMapper.selectById(sit.getRoomId());
        //roomMapper是映射器接口实现类，Mapper数据库中的数据映射以及将数据保存到数据库中
        //selectById根据指定roomId查询自习室信息。
        //sit.getRoomId()调用实体类中的getRoomId方法获取自习室编号
        //room存储查询信息
        if (ObjectUtil.isEmpty(room)) {
            throw new CustomException(ResultCodeEnum.TYPE_NO_ERROR);
        }
        if (ObjectUtil.isEmpty(room.getLibadminId())) {
            throw new CustomException(ResultCodeEnum.TYPE_LIBADMIN_NO_ERROR);
        }
        sit.setLibadminId(room.getLibadminId());
        //座位默认状态
        //enums包下创建枚举StatusEnum.java
        sit.setStatus(StatusEnum.OK.status);
        sitMapper.insert(sit);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        sitMapper.deleteById(id);
    }

    /**
     * 批量删除
     */
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            sitMapper.deleteById(id);
        }
    }

    /**
     * 修改
     */
    public void updateById(Sit sit) {
        sitMapper.updateById(sit);
    }

    /**
     * 根据ID查询
     */
    public Sit selectById(Integer id) {
        return SitMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Sit> selectAll(Sit sit) {
        return sitMapper.selectAll(sit);
    }

    /**
     * 分页查询
     */
    public PageInfo<Sit> selectPage(Sit sit, Integer pageNum, Integer pageSize) {
        Account currentUser = TokenUtils.getCurrentUser();
        if (RoleEnum.LIBADMIN.name().equals(currentUser.getRole())) {
            sit.setLibadminId(currentUser.getId());
        }
        PageHelper.startPage(pageNum, pageSize);
        List<Sit> list = sitMapper.selectAll(sit);
        return PageInfo.of(list);
    }

}