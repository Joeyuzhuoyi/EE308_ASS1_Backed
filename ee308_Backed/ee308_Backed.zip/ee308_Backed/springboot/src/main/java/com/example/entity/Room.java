package com.example.entity;

import java.io.Serializable;
//自习室表
public class Room implements Serializable {
    private static final long serialVersionUID = 1L;

    /** ID */
    private Integer id;
    private String name;
    private String descr;
    private Integer libadminId;

    private String libadminName;//管理员关联查询

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public Integer getLibadminId() {
        return libadminId;
    }

    public void setLibadminId(Integer libadminId) {
        this.libadminId = libadminId;
    }

    public String getLibadminName() {
        return libadminName;
    }

    public void setLibadminName(String libadminName) {
        this.libadminName = libadminName;
    }
}