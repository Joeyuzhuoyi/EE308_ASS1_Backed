package com.example.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.common.Constants;
import com.example.common.enums.ResultCodeEnum;
import com.example.common.enums.RoleEnum;
import com.example.entity.Account;
import com.example.entity.Libadmin;
import com.example.exception.CustomException;
import com.example.mapper.LibadminMapper;
import com.example.utils.TokenUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 自习室管理员业务处理
 **/
@Service
public class LibadminService {

    @Resource
    private LibadminMapper libadminMapper;

    /**
     * 新增
     */
    public void add(Libadmin libadmin) {
        Libadmin dbLibadmin = libadminMapper.selectByUsername(libadmin.getUsername());
        if (ObjectUtil.isNotNull(dbLibadmin)) {
            throw new CustomException(ResultCodeEnum.USER_EXIST_ERROR);
        }
        if (ObjectUtil.isEmpty(libadmin.getPassword())) {
            libadmin.setPassword(Constants.USER_DEFAULT_PASSWORD);
        }
        if (ObjectUtil.isEmpty(libadmin.getName())) {
            libadmin.setName(libadmin.getUsername());
        }
        libadmin.setRole(RoleEnum.LIBADMIN.name());
        libadminMapper.insert(libadmin);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        libadminMapper.deleteById(id);
    }

    /**
     * 批量删除
     */
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            libadminMapper.deleteById(id);
        }
    }

    /**
     * 修改
     */
    public void updateById(Libadmin libadmin) {
        libadminMapper.updateById(libadmin);
    }

    /**
     * 根据ID查询
     */
    public Libadmin selectById(Integer id) {
        return libadminMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Libadmin> selectAll(Libadmin libadmin) {
        return libadminMapper.selectAll(libadmin);
    }

    /**
     * 分页查询
     */
    public PageInfo<Libadmin> selectPage(Libadmin libadmin, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Libadmin> list = libadminMapper.selectAll(libadmin);
        return PageInfo.of(list);
    }

    /**
     * 登录
     */
    public Account login(Account account) {
        //通过用户名查询
        Account dbLabadmin = libadminMapper.selectByUsername(account.getUsername());
        if (ObjectUtil.isNull(dbLabadmin)) {
            //不存在
            throw new CustomException(ResultCodeEnum.USER_NOT_EXIST_ERROR);
        }
        //存在，校验密码
        if (!account.getPassword().equals(dbLabadmin.getPassword())) {
            throw new CustomException(ResultCodeEnum.USER_ACCOUNT_ERROR);
        }
        // 生成token，根据id和角色生成字符串，前端生成token为后续后台调用。后台jwt获取token在数据库进行判断
        String tokenData = dbLabadmin.getId() + "-" + RoleEnum.LIBADMIN.name();
        String token = TokenUtils.createToken(tokenData, dbLabadmin.getPassword());
        dbLabadmin.setToken(token);
        return dbLabadmin;
    }
    /**
     * 修改密码
     */
    public void updatePassword(Account account) {
        Libadmin dbLabadmin = libadminMapper.selectByUsername(account.getUsername());
        if (ObjectUtil.isNull(dbLabadmin)) {
            throw new CustomException(ResultCodeEnum.USER_NOT_EXIST_ERROR);
        }
        if (!account.getPassword().equals(dbLabadmin.getPassword())) {
            throw new CustomException(ResultCodeEnum.PARAM_PASSWORD_ERROR);
        }
        dbLabadmin.setPassword(account.getNewPassword());
        libadminMapper.updateById(dbLabadmin);
    }
}