package com.example.controller;

import com.example.common.Result;
import com.example.entity.Libadmin;
import com.example.service.LibadminService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 自习室管理员前端操作接口
 **/
@RestController
@RequestMapping("/libadmin")
public class LibadminController {

    @Resource
    private LibadminService libadminService;

    /**
     * 新增
     */
    @PostMapping("/add")
    public Result add(@RequestBody Libadmin libadmin) {
        libadminService.add(libadmin);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        libadminService.deleteById(id);
        return Result.success();
    }

    /**
     * 批量删除
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        libadminService.deleteBatch(ids);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Libadmin libadmin) {
        libadminService.updateById(libadmin);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Libadmin libadmin = libadminService.selectById(id);
        return Result.success(libadmin);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Libadmin libadmin ) {
        List<Libadmin> list = libadminService.selectAll(libadmin);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Libadmin libadmin,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Libadmin> page = libadminService.selectPage(libadmin, pageNum, pageSize);
        return Result.success(page);
    }

}