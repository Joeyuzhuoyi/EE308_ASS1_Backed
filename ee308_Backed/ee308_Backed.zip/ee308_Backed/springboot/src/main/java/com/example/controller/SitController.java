package com.example.controller;

import com.example.common.Result;
import com.example.entity.Sit;
import com.example.service.SitService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 座位前端操作接口
 **/
@RestController
@RequestMapping("/sit")
public class SitController {

    @Resource
    private SitService sitService;

    /**
     * 新增
     */
    @PostMapping("/add")
    public Result add(@RequestBody Sit sit) {
        sitService.add(sit);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        sitService.deleteById(id);
        return Result.success();
    }

    /**
     * 批量删除
     */
    @DeleteMapping("/delete/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        sitService.deleteBatch(ids);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Sit sit) {
        sitService.updateById(sit);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Sit sit = sitService.selectById(id);
        return Result.success(sit);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Sit sit ) {
        List<Sit> list = sitService.selectAll(sit);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Sit sit,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Sit> page = sitService.selectPage(sit, pageNum, pageSize);
        return Result.success(page);
    }

}