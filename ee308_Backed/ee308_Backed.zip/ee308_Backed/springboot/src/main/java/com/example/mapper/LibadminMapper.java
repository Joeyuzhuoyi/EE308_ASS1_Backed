package com.example.mapper;

import com.example.entity.Libadmin;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作libadmin相关数据接口
*/
public interface LibadminMapper {

    /**
      * 新增
    */
    int insert(Libadmin libadmin);

    /**
      * 删除
    */
    int deleteById(Integer id);

    /**
      * 修改
    */
    int updateById(Libadmin libadmin);

    /**
      * 根据ID查询
    */
    Libadmin selectById(Integer id);

    /**
      * 查询所有
    */
    List<Libadmin> selectAll(Libadmin libadmin);

    @Select("select * from libadmin where username = #{username}")
    Libadmin selectByUsername(String username);
}