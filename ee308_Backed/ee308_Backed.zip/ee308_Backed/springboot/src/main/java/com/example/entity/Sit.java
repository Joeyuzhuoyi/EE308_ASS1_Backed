package com.example.entity;

import java.io.Serializable;

//座位表
public class Sit implements Serializable {
    private static final long serialVersionUID = 1L;

    /** ID */
    private Integer id;
    private String name;
    private String descr;
    private String start;
    private String end;
    private String status;
    private Integer roomId;
    private Integer libadminId;
    //再写两个字段关联查询
    private String roomName;
    private String libadminName;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Integer getLibadminId() {
        return libadminId;
    }

    public void setLibadminId(Integer libadminId) {
        this.libadminId = libadminId;
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getLibadminName() {
        return libadminName;
    }

    public void setLibadminName(String libadminName) {
        this.libadminName = libadminName;
    }

}